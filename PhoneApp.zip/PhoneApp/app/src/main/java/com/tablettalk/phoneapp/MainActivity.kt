package com.tablettalk.phoneapp

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView

    private val requiredPermissions = arrayOf(
        android.Manifest.permission.READ_PHONE_STATE,
        android.Manifest.permission.READ_CALL_LOG,
        android.Manifest.permission.CALL_PHONE,
        android.Manifest.permission.ANSWER_PHONE_CALLS,
        android.Manifest.permission.READ_CONTACTS,
        android.Manifest.permission.BLUETOOTH,
        android.Manifest.permission.BLUETOOTH_ADMIN,
        android.Manifest.permission.ACCESS_FINE_LOCATION
    )

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        Toast.makeText(
            this,
            if (allGranted) "تم منح جميع الصلاحيات" else "بعض الصلاحيات لم تُمنح",
            Toast.LENGTH_SHORT
        ).show()
        refreshStatus()
    }

    private val defaultDialerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("phone_app_prefs", MODE_PRIVATE)
        statusText = findViewById(R.id.statusText)

        findViewById<Button>(R.id.btnGrantPermissions).setOnClickListener {
            permissionLauncher.launch(requiredPermissions)
        }

        findViewById<Button>(R.id.btnSetDefaultDialer).setOnClickListener {
            requestDefaultDialer()
        }

        findViewById<Button>(R.id.btnSelectTablet).setOnClickListener {
            showPairedDevicesDialog()
        }

        findViewById<Button>(R.id.btnStartService).setOnClickListener {
            val intent = Intent(this, BluetoothLinkService::class.java)
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "تم بدء خدمة الربط", Toast.LENGTH_SHORT).show()
        }

        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun hasAllPermissions(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(this, it) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    private fun isDefaultDialer(): Boolean {
        val telecomManager = getSystemService(TelecomManager::class.java)
        return telecomManager?.defaultDialerPackage == packageName
    }

    private fun requestDefaultDialer() {
        val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
        intent.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
        defaultDialerLauncher.launch(intent)
    }

    private fun showPairedDevicesDialog() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "يرجى منح صلاحيات البلوتوث أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            Toast.makeText(this, "هذا الجهاز لا يدعم البلوتوث", Toast.LENGTH_SHORT).show()
            return
        }
        if (!adapter.isEnabled) {
            Toast.makeText(this, "يرجى تفعيل البلوتوث أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        val devices: Set<BluetoothDevice> = adapter.bondedDevices
        if (devices.isEmpty()) {
            Toast.makeText(this, "لا توجد أجهزة مزاوجة. قم بمزاوجة التابلت من إعدادات البلوتوث أولاً", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name}\n${it.address}" }.toTypedArray()
        val addresses = devices.map { it.address }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("اختر جهاز التابلت")
            .setItems(names) { _, which ->
                prefs.edit().putString("tablet_address", addresses[which]).apply()
                Toast.makeText(this, "تم حفظ التابلت: ${names[which]}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun refreshStatus() {
        val perms = if (hasAllPermissions()) "✓ ممنوحة" else "✗ ناقصة"
        val dialer = if (isDefaultDialer()) "✓ مُعيَّن" else "✗ غير مُعيَّن"
        val tablet = prefs.getString("tablet_address", null) ?: "لم يُحدد"
        statusText.text = "الصلاحيات: $perms\nتطبيق الهاتف الافتراضي: $dialer\nالتابلت المحدد: $tablet"
    }
}
