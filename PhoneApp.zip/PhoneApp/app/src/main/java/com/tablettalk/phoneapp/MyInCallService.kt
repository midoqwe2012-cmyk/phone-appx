package com.tablettalk.phoneapp

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService
import android.util.Log

/**
 * هذه الخدمة لا تعمل إلا إذا كان هذا التطبيق معيّناً كتطبيق الهاتف (Dialer) الافتراضي.
 * يزودنا أندرويد تلقائياً بكائن Call عند الرنين/قبول/انتهاء أي مكالمة،
 * ونحن نستخدمه لإعلام التابلت بالحالة، وننفذ أوامر الرد/الرفض القادمة من التابلت.
 */
class MyInCallService : InCallService() {

    companion object {
        private const val TAG = "MyInCallService"
        @Volatile var activeCall: Call? = null
    }

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            handleState(call, state)
        }
    }

    override fun onCreate() {
        super.onCreate()
        // تشغيل خدمة الربط مع التابلت إن لم تكن تعمل، واستقبال أوامرها
        val svcIntent = Intent(this, BluetoothLinkService::class.java)
        startForegroundService(svcIntent)
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        activeCall = call
        call.registerCallback(callCallback)
        handleState(call, call.state)

        // ربط أوامر التابلت بهذه المكالمة المحددة
        BluetoothLinkService.instance?.onCommandReceived = { type, _ ->
            when (type) {
                Protocol.ANSWER -> activeCall?.answer(0)
                Protocol.REJECT -> activeCall?.reject(false, null)
            }
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(callCallback)
        if (activeCall == call) activeCall = null
        BluetoothLinkService.instance?.sendToTablet(Protocol.CALL_ENDED)
    }

    private fun handleState(call: Call, state: Int) {
        val number = call.details?.handle?.schemeSpecificPart ?: "غير معروف"
        when (state) {
            Call.STATE_RINGING -> {
                Log.d(TAG, "رنين: $number")
                BluetoothLinkService.instance?.sendToTablet(Protocol.RINGING, number)
            }
            Call.STATE_ACTIVE -> {
                BluetoothLinkService.instance?.sendToTablet(Protocol.CALL_ACTIVE, number)
            }
            Call.STATE_DISCONNECTED -> {
                BluetoothLinkService.instance?.sendToTablet(Protocol.CALL_ENDED)
            }
        }
    }
}
