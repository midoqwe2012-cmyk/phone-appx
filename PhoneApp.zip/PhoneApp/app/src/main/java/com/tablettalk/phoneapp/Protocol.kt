package com.tablettalk.phoneapp

/**
 * بروتوكول رسائل نصية بسيطة تُرسل عبر Bluetooth RFCOMM.
 * كل رسالة سطر واحد بصيغة: TYPE|DATA
 *
 * من الهاتف إلى التابلت:
 *   RINGING|اسم أو رقم المتصل
 *   CALL_ACTIVE|اسم أو رقم المتصل
 *   CALL_ENDED|
 *
 * من التابلت إلى الهاتف:
 *   ANSWER|
 *   REJECT|
 */
object Protocol {
    const val RINGING = "RINGING"
    const val CALL_ACTIVE = "CALL_ACTIVE"
    const val CALL_ENDED = "CALL_ENDED"
    const val ANSWER = "ANSWER"
    const val REJECT = "REJECT"

    // UUID فريد وثابت يجب أن يتطابق في تطبيق الهاتف وتطبيق التابلت
    const val APP_UUID_STRING = "8ce255c0-200a-11e0-ac64-0800200c9a66"

    fun build(type: String, data: String = ""): String = "$type|$data\n"

    fun parse(line: String): Pair<String, String>? {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return null
        val idx = trimmed.indexOf('|')
        return if (idx == -1) Pair(trimmed, "") else Pair(trimmed.substring(0, idx), trimmed.substring(idx + 1))
    }
}
