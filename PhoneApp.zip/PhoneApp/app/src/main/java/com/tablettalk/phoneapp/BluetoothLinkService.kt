package com.tablettalk.phoneapp

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * خدمة تعمل في الخلفية على الهاتف وتستضيف اتصال Bluetooth RFCOMM قادم من تطبيق التابلت.
 * تستمر بقبول الاتصالات وتعيد المحاولة عند الانقطاع.
 * تُستخدم لإرسال حالة المكالمات إلى التابلت واستقبال أوامر الرد/الرفض منه.
 */
class BluetoothLinkService : Service() {

    companion object {
        const val CHANNEL_ID = "bt_link_channel"
        const val NOTIF_ID = 1001

        // مرجع وحيد يستخدمه باقي التطبيق (مثل MyInCallService) لإرسال البيانات للتابلت
        @Volatile
        var instance: BluetoothLinkService? = null
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var serverSocket: BluetoothServerSocket? = null
    private var clientSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    @Volatile private var running = false

    // يستدعى عند استقبال أمر من التابلت (ANSWER / REJECT)
    var onCommandReceived: ((type: String, data: String) -> Unit)? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification("بانتظار اتصال التابلت...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        if (!running) {
            running = true
            executor.execute { listenLoop() }
        }
        return START_STICKY
    }

    private fun listenLoop() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        while (running) {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(
                    "TabletTalkPhone", UUID.fromString(Protocol.APP_UUID_STRING)
                )
                val socket = serverSocket?.accept() ?: continue
                clientSocket = socket
                outputStream = socket.outputStream
                updateNotification("متصل بالتابلت")
                readLoop(socket)
            } catch (e: IOException) {
                // الاتصال انقطع أو فشل؛ أعد المحاولة بعد تأخير قصير
                updateNotification("بانتظار اتصال التابلت...")
                Thread.sleep(2000)
            }
        }
    }

    private fun readLoop(socket: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.inputStream))
            while (running) {
                val line = reader.readLine() ?: break
                val parsed = Protocol.parse(line) ?: continue
                onCommandReceived?.invoke(parsed.first, parsed.second)
            }
        } catch (e: IOException) {
            // انقطع الاتصال
        } finally {
            try { socket.close() } catch (_: IOException) {}
            outputStream = null
        }
    }

    /** إرسال رسالة إلى التابلت إن كان متصلاً. يعيد true إذا نجح الإرسال. */
    fun sendToTablet(type: String, data: String = ""): Boolean {
        val out = outputStream ?: return false
        return try {
            out.write(Protocol.build(type, data).toByteArray())
            out.flush()
            true
        } catch (e: IOException) {
            false
        }
    }

    fun isTabletConnected(): Boolean = outputStream != null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "اتصال التابلت", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Tablet Talk")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            ?.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        running = false
        try { clientSocket?.close() } catch (_: IOException) {}
        try { serverSocket?.close() } catch (_: IOException) {}
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
